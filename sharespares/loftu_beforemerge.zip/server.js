const config = require('./app/config/config')
const groupsRouter = require("./app/routes/groupRoutes")
const itemsRouter = require('./app/routes/itemRoutes')
const middleware = require('./app/utils/middleware')
const loginRouter = require("./app/routes/loginRoutes")
const logger = require('./app/utils/logger')

const express = require("express")
require('express-async-errors')
const app = express();


const bodyParser = require("body-parser")
// parse requests of content-type: application/json
app.use(bodyParser.json());

// parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
const cors = require('cors')

app.use(cors());

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to Loftu application." });
});

app.post('/auth', function(request, response) {
	var email = request.body.email;
	var password = request.body.password;
  console.log(email)
  console.log(password)
	if (email && password) {
		connection.query('SELECT * FROM loftu_members WHERE email = ? AND password = ?', [email, password], function(error, results, fields) {
			if (results.length > 0) {
				request.session.loggedin = true;
				request.session.username = email;
				response.redirect('/home');
			} else {
				response.send('Incorrect email and/or Password!');
			}			
			response.end();
		});
	} else {
		response.send('Please enter email and Password!');
		response.end();
	}
});

app.get('/home', function(request, response) {
	if (request.session.loggedin) {
		response.send('Welcome back, ' + request.session.username + '!');
	} else {
		response.send('Please login to view this page!');
	}
	response.end();
});

//app.use((req, res, next) => {
//  res.setHeader('Access-Control-Allow-Origin', '*');
//  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
//  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
//  next();
//});


app.use('/api/groups', groupsRouter);
app.use('/api/items', itemsRouter);
app.use('/', loginRouter);

// set port, listen for requests
app.listen(4000, () => {
  console.log("Server is running on port 4000.");
});