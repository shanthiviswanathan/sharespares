const sql = require("./db.js");

// constructor
const Group = function(group) {
  this.name = group.name;
  this.description = group.description;
  this.status = group.status;
  this.admin = group.admin;
  this.location = group.location;
  this.start_datetime = null;
  this.end_datetime = null;
  this.member_limit = group.member_limit;
  this.approval_process = group.approval_process;
  this.ask_signup_question = group.ask_signup_question;
  this.rsvp_starttime = null;
  this.rsvp_endtime = null;
};

Group.create = (newGroup, result) => {
  sql.query("INSERT INTO loftu_groups SET ?", newGroup, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created group: ", { id: res.insertId, ...newGroup });
    result(null, { id: res.insertId, ...newGroup });
  });
};

Group.findById = (groupId, result) => {
  sql.query(`SELECT * FROM loftu_groups WHERE id = ${groupId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found group: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Group with the id
    result({ kind: "not_found" }, null);
  });
};

Group.getAll = result => {
  sql.query("SELECT * FROM loftu_groups", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("groups: ", res);
    result(null, res);
  });
};

Group.updateById = (id, group, result) => {
  sql.query(
    "UPDATE loftu_groups SET name = ?, description = ?, status = ?, admin = ?, location = ?, member_limit = ?, approval_process = ?, ask_signup_question = ? WHERE id = ?",
    [group.name, group.description, group.status, group.admin, group.location, group.member_limit, group.approval_process, group.ask_signup_question, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Group with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated group: ", { id: id, ...group });
      result(null, { id: id, ...group });
    }
  );
};

Group.remove = (id, result) => {
  sql.query("DELETE FROM loftu_groups WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Group with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted group with id: ", id);
    result(null, res);
  });
};

Group.removeAll = result => {
  sql.query("DELETE FROM loftu_groups", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} groups`);
    result(null, res);
  });
};

module.exports = Group;