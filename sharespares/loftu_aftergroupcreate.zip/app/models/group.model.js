const sql = require("./db.js");

// constructor
const Group = function(group) {
  this.name = group.name;
  this.description = group.description;
  this.status = group.status;
  this.admin = group.admin;
  this.location = group.location;
  this.start_datetime = group.start_datetime;
  this.end_datetime = group.end_datetime;
  this.member_limit = group.member_limit;
  this.approval_process = group.approval_process;
  this.ask_signup_question = group.ask_signup_question;
  this.rsvp_starttime = group.rsvp_starttime;
  this.rsvp_endtime = group.rsvp_endtime;
};  

function createGroup (newGroup) {
  return new Promise ((resolve, reject) => {
    sql.query("INSERT INTO loftu_groups SET ?", newGroup, (err, res) => err ? reject(err): resolve(res))
  })
}

function createGroupMember (id, newGroup, memType) {
  return new Promise ((resolve, reject) => {
    sql.query("INSERT INTO loftu_group_members (group_id, member_id, status, subscribe_datetime, member_type) VALUES (?,?, ?, ?, ?)", [id, newGroup.admin, newGroup.status, newGroup.start_datetime, memType], (err, res) => err ? reject(err): resolve(res))
  })
}

Group.create = async (newGroup, memType, result) => {
    var grpId = ''
    try {
      res = await createGroup(newGroup)
      console.log(res)
      res = await createGroupMember(res.insertId, newGroup, memType)
      result(null, res);
      return;
    }
    catch(err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
  
}

Group.findById = (groupId, result) => {
  sql.query(`SELECT * FROM loftu_groups WHERE id = ${groupId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found group: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Group with the id
    result({ kind: "not_found" }, null);
  });
};

Group.findByUserId = (userId, result) => {
  sql.query(`SELECT g.* FROM loftu_groups g, logtu_group_members m WHERE m.member_id = ${userId} AND g.id = m.group_id`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found group: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Group with the id
    result({ kind: "not_found" }, null);
  });
};

Group.getAll = result => {
  sql.query("SELECT * FROM loftu_groups", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("groups: ", res);
    result(null, res);
  });
};

Group.updateById = (id, group, result) => {
  sql.query(
    "UPDATE loftu_groups SET name = ?, description = ?, status = ?, admin = ?, location = ?, member_limit = ?, approval_process = ?, ask_signup_question = ? WHERE id = ?",
    [group.name, group.description, group.status, group.admin, group.location, group.member_limit, group.approval_process, group.ask_signup_question, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Group with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated group: ", { id: id, ...group });
      result(null, { id: id, ...group });
    }
  );
};

Group.remove = (id, result) => {
  sql.query("DELETE FROM loftu_groups WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Group with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted group with id: ", id);
    result(null, res);
  });
};

Group.removeAll = result => {
  sql.query("DELETE FROM loftu_groups", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} groups`);
    result(null, res);
  });
};

module.exports = Group;