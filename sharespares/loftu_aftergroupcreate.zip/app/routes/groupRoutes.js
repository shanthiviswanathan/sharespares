//initialize
  const express = require('express');
  const router = express.Router();

  const groups = require("../controllers/group.controller.js");

  // Create a new Group
  router.post("/groups", groups.create);

  // Retrieve all Groups
  router.get("/groups", groups.findAll);

  // Retrieve a single Group with groupId
  router.get("/groups/:groupId", groups.findOne);
  
  // Retrieve all groups a user belongs to
  router.get("/groups/:userId", groups.findAll);

  // Update a Group with groupId
  router.put("/groups/:groupId", groups.update);

  // Delete a Group with groupId
  router.delete("/groups/:groupId", groups.delete);

  // Create a new Group
  router.delete("/groups", groups.deleteAll);
  
   module.exports = router;

