require('dotenv').config()

let PORT = process.env.PORT || 3000


module.exports = {
  PORT
}